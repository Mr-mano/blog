<?php
http_response_code(404);
?>

<h1>Page introuvable</h1>