<?php
function e (string $string){
    return htmlentities($string);
}